from flask import Flask, render_template, request, redirect

app = Flask(__name__)

TODOS = ["Feed the dog", "Clean my room", "Wash the car"]
DATES = ["2025-02-10", "2025-02-11", "2025-04-12"]

@app.route("/")
def index():
    return render_template("index.html", num_tasks=len(TODOS))

@app.route("/add")
def add():
    # show a form for the user to add a new task
    return render_template("add.html")


@app.route("/submit")
def submit():
    # get the data from the form
    task = request.args.get("task", "")
    task_date = request.args.get("task-date", "")
    # validation
    if task == "":
        msg = "Please enter a valid task."
        return render_template("error.html", error_msg=msg)
    elif task_date == "":
        msg = "Invalid date for this task"
        return render_template("error.html", error_msg=msg)
    else:
        # now add the task to the TODOS list
        TODOS.append(task)
        DATES.append(task_date)
        return redirect("/show")

@app.route("/show")
def show():
    # show a list of all the TODOS
    task_list = TODOS
    return render_template("show.html", task_list=task_list, task_dates=DATES)

